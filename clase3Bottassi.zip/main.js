// Definir una función que acepte dos parámetros. Una cadena de caracteres (string) y un
// caracter. Esta función deberá devolver la cantidad de veces que el “caracter” se
// encuentra en la “cadena” provista. Ejemplo, si a la función se le pasara la cadena
// “abracadabra” junto con el carácter “a”, la función deberá devolver 5.
let cadena = prompt("Elija una palabra en minúscula");
let caracter = prompt("Elija un caracter en minúscula de la palabra escrita anteriormente");

function miFuncion(cadena,caracter){
    let contador = 0;
    for (let i = 0; i <= cadena.length; i++) {
       if(caracter == cadena[i]){
           contador++
       } 
    }
    console.log("El caracter "+ caracter + " se encuentra "+ contador + " veces en la cadena "+ cadena);
}
miFuncion(cadena,caracter);
