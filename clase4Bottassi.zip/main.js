const productos = [
    {id: 1, burger: "Fresh Burger", price: 1.030 , stock: true},
    {id: 2,burger: "Special Bacon", price: 1.330 , stock: false},
    {id: 3,burger: "Le Blue", price: 1.110 , stock: true},
    {id: 4,burger: "Burger Stacker Quintuple", price: 1.480 , stock: true},
    {id: 5,burger: "Doble Cheese Burger", price: 1.170 , stock: true}
];
for (let i = 0; i < productos.length; i++) {
    let burger= prompt("Elija su hamburguesa");
    let total = 0;
    if (burger == productos[i].burger && productos[i].stock) {
        total++
        console.log(productos[i]);
        console.log("Productos totales "+total);
    }
    
    
}


/**
 * Intente hacer lo mismo que toto para empezar pero no me salio
 */
/* Debería aparecerme en el html esta card creada con el for pero no me aparece */
let acumulador = ``;
for (let i = 0; i < productos.length; i++) {
    if (productos[i].stock) {
    acumulador += `<div> ${productos[i].burger} - $${productos[i].price} <br>
    <button onclick="agregarAlCarrito(${productos[i].id})">Agregar</button> </div>`;
    }
}

/*No entiendo como hacer que funcione en la consola del navegador como para que me aparezca el resultado de agregar carrito*/

let productosEnElCarrito =[];
function agregarAlCarrito(idDeProducto){
    
    const indiceEncontrado = productos.findIndex(producto => producto.id == idDeProducto);
    
    productosEnElCarrito.push(productos[indiceEncontrado]);
    
    console.log(productosEnElCarrito);
    
}

document.write(acumulador);





